function ShortlistedResumes(){
    return(
        <>
            <div>
                <h1>Shortlisted resumes</h1>
            </div>
        </>
    )
}

export default ShortlistedResumes;