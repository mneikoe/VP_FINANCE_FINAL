function JobProfileTarget(){
    return(
        <>
            <div>
                <h1>Job profile target</h1>
            </div>
        </>
    )
}

export default JobProfileTarget;