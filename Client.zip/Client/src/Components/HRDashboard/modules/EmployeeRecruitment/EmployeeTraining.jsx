function EmployeeTraining(){
    return(
        <>
            <div>
                <h1>Employee training</h1>
            </div>
        </>
    )
}

export default EmployeeTraining;