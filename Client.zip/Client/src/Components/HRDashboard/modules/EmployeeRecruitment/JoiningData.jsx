function JoiningData(){
    return(
        <>
            <div>
                <h1>Joining Data</h1>
            </div>
        </>
    )
}

export default JoiningData;