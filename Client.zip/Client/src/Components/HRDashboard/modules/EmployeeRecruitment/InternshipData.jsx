function InternshipData(){
    return(
        <>
            <div>
                <h1>Internship data</h1>
            </div>
        </>
    )
}

export default InternshipData;