function RulesRegulations(){
    return(
        <>
            <div>
                <h1>Rules & regulations</h1>
            </div>
        </>
    )
}

export default RulesRegulations;