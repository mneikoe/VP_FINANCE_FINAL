function InterviewProcess(){
    return(
        <>
            <div>
                <h1>Interview process</h1>
            </div>
        </>
    )
}

export default InterviewProcess;