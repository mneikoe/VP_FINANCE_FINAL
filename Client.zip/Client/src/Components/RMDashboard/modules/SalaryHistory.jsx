import React from "react";

const SalaryHistory = () => {
  return (
    <div className="salary-history-page">
      <h2>Salary History</h2>
      <p>View salary history and records.</p>
    </div>
  );
};

export default SalaryHistory;
