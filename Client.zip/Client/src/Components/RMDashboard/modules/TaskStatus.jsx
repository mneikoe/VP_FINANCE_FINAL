import React from "react";

const TaskStatus = () => {
  return (
    <div className="task-status-page">
      <h2>Task Status</h2>
      <p>Current status of all tasks.</p>
    </div>
  );
};

export default TaskStatus;
