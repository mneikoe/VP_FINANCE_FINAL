import React from "react";

const WorkDescription = () => {
  return (
    <div className="work-description-page">
      <h2>Work Description</h2>
      <p>Work description and responsibilities.</p>
    </div>
  );
};

export default WorkDescription;
