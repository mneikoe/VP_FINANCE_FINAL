import React from "react";

const IncentiveHistory = () => {
  return (
    <div className="incentive-history-page">
      <h2>Incentive History</h2>
      <p>Incentive calculations and history.</p>
    </div>
  );
};

export default IncentiveHistory;
