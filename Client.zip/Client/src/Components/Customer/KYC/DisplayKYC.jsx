import React from "react";

function DisplayKYC() {
  return <div>DisplayKYC</div>;
}

export default DisplayKYC;
