import React from "react";

function AddKYC() {
  return <div>AddKYC</div>;
}

export default AddKYC;
